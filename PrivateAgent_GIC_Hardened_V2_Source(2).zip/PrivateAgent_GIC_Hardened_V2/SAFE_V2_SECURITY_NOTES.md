# PrivateAgent Safe V2 — security notes

V2 re-enables Android Accessibility-based screen interaction. The service can inspect visible UI content and perform taps, text entry, scrolling, swipes, Back, and Home actions. This is a high-trust Android capability. Enable the Accessibility service only after reviewing the source and only while you understand what the agent can see and do.

## Retained restrictions

- Direct call, SMS, and contact actions remain blocked by the central action handler.
- ADB/shell commands remain blocked; the multi-step executor no longer falls back to Shizuku commands for gestures or keyboard submission.
- Telegram remote control remains disabled.
- API key storage remains migrated to Android secure storage.
- The app uses a distinct V2 package ID so the V1 app is not replaced.
- A task is capped at 20 action steps and the existing Stop/cancel path remains in place.

## What this does not guarantee

The task planner is instructed not to send, submit, buy, pay, transfer, post, share, upload, delete, or enter secrets. These are model instructions, not a cryptographically enforced per-tap approval barrier. Accessibility can activate unlabeled or misidentified controls. Therefore this build must be treated as experimental and should not be used for financial, messaging, authentication, account-management, or other consequential tasks. Keep the phone in view during use.

## Validation status

The source and Android configuration can be statically inspected, but this environment does not have Flutter/Dart installed. No Flutter analyzer, unit tests, Gradle build, APK, or device test has been completed.
