# Safe V1 change log

- Added Android Keystore-backed API-key storage with legacy preference migration.
- Removed request/response/screen/task content from diagnostic logs in AI and task paths.
- Disabled Telegram remote-control polling and removed its settings UI.
- Added central deny rules for calls, SMS, contacts, shell commands, screen mutation,
  and multi-step autonomous tasks.
- Removed broad/sensitive Android permissions and added manifest-merger removal rules.
- Changed application ID and app label to keep this fork separate from upstream; disabled app backup and cleartext traffic; made the internal background receiver non-exported.
- Removed debug-key signing from the release build configuration.
- Added security notes and explicit disclosure of remaining limitations.
