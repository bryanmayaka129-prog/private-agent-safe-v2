# PrivateAgent Safe V2 change log

- Uses a separate Android application ID (`com.orailnoor.privateagent.safev2`) and label so V1 remains installed and unchanged.
- Enables Accessibility-based screen reading, tapping, typing, scrolling, swiping, app navigation, and multi-step tasks.
- Keeps direct calls, SMS, contact lookup, and ADB/shell actions centrally blocked.
- Removes Shizuku/ADB fallback execution from the multi-step task runner; screen gestures use the Android Accessibility service only.
- Caps each multi-step task at 20 actions, even if the app's unlimited-steps preference is enabled. Existing Stop/cancel handling remains available.
- AI instructions prohibit secrets, messages, form submissions, financial actions, publishing, sharing, deletion, and other consequential operations.
- Keeps the floating overlay disabled by default and Telegram remote control disabled.

## Important limitations

This is not a per-action approval system. Accessibility taps can activate controls in other apps, and AI instructions cannot guarantee that every risky or unlabeled control will be recognized. Keep the phone visible while testing, do not give it sensitive tasks, and use the Stop control if it behaves unexpectedly. Do not use this build for banking, trading, payments, purchases, messaging, account changes, or other high-impact tasks.

## Build status

Source changes and static checks only. Flutter/Dart SDK was not available in the editing environment, so no Flutter analysis, test run, or APK build was completed.
