class FeatureFlags {
  FeatureFlags._();

  // V2 enables user-initiated Accessibility-based screen automation.
  // The floating overlay remains off by default.
  static const bool floatingOverlayEnabled = false;
  static const bool autonomousScreenActionsEnabled = true;
}
