
/// Remote Telegram control is deliberately disabled in Safe V1.
/// The original polling implementation is not shipped in this build.
class TelegramService {
  TelegramService(Object actionHandler, Object aiService);

  String get botToken => '';
  bool get isEnabled => false;

  Future<void> init() async {
    // Remove any bot token left by an earlier upstream installation.
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('telegram_bot_token');
    await prefs.remove('telegram_enabled');
  }

  Future<void> saveSettings({required String botToken, required bool isEnabled}) async {
    // Intentionally ignore attempts to enable remote control.
  }

  void startPolling() {}
  void stopPolling() {}
  void dispose() {}
}
