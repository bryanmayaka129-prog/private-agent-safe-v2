# PrivateAgent Safe V1 — security notes

This is a conservative source fork of the supplied `private-agent-main` project.
It is not the original upstream application and it is not a completed security
certification.

## Safe V1 restrictions

- Telegram polling/remote control is removed and its settings card is hidden.
- Phone calls, SMS, contact lookup, Shizuku/ADB commands, direct screen clicks,
  typing, scrolling, and multi-step autonomous tasks are denied centrally by
  `ActionHandler`.
- Screen reading remains available only when explicitly requested. Accessibility
  access can expose text from other apps; Android's Accessibility settings must
  be treated as a high-trust permission.
- API keys are stored with `flutter_secure_storage` (Android Keystore-backed
  storage) and legacy plaintext SharedPreferences keys are migrated then deleted.
- API request bodies, model responses, screen dumps, and task prompts are no
  longer written to diagnostic logs in the modified paths.
- Broad contacts, phone, SMS, phone-state, write-settings, and package-query
  permissions are removed/stripped from the Android manifest.
- App ID is changed to `com.orailnoor.privateagent.safe` so it does not replace
  the original package on a device. Android app backup is disabled, cleartext
  network traffic is disallowed, and the internal background receiver is no
  longer exported.
- Release builds are no longer signed with the Android debug key.

## Important limitations

1. This is a restricted, read-only-first build, not a full phone-control agent.
   Automated interaction is intentionally disabled until a separate, reviewed
   per-action approval design is implemented and tested.
2. The AI provider still receives the user message and any screen description
   that the user explicitly asks the app to read. Review the provider's privacy
   and data-retention terms before entering sensitive information.
3. Accessibility service code remains present because screen reading is part of
   the retained feature. Do not enable Accessibility unless you understand that
   it can inspect content displayed by other apps.
4. Dependency/plugin manifest merging must be verified on a real Android build.
   The explicit `tools:node="remove"` entries are intended to strip the listed
   permissions from merged manifests, but this archive has not yet been built.
5. The original source archive and original APK were not modified. This fork
   does not prove that the upstream prebuilt APK matches the source.
6. No APK is included. A successful Flutter/Android build and APK signature
   verification are still required before installation.

## Build prerequisites

- Flutter SDK compatible with the Dart constraint in `pubspec.yaml` (Dart 3.10+)
- Android SDK / Android Gradle tooling required by the Flutter version
- Network access to resolve pub dependencies

Run `flutter pub get`, `flutter analyze`, `flutter test`, then build a release
APK using a private keystore. Never commit a keystore or passwords to Git.

## Files changed

See `CHANGELOG_SAFE_V1.md` for the exact hardening changes.
