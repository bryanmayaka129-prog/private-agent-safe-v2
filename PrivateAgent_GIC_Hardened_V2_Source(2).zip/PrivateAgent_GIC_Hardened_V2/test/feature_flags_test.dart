import 'package:flutter_test/flutter_test.dart';
import 'package:private_agent/config/feature_flags.dart';

void main() {
  test('V2 enables Accessibility screen automation by default', () {
    expect(FeatureFlags.autonomousScreenActionsEnabled, isTrue);
  });

  test('floating overlay remains disabled by default', () {
    expect(FeatureFlags.floatingOverlayEnabled, isFalse);
  });
}
