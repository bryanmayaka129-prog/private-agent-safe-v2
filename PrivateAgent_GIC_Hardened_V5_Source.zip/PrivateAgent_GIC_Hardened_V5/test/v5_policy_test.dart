import 'package:flutter_test/flutter_test.dart';
import 'package:private_agent/services/command_gateway.dart';
import 'package:private_agent/services/emergency_stop_controller.dart';
import 'package:private_agent/services/specialist_registry.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('V5 specialist detection', () {
    test('detects game requests', () {
      expect(SpecialistRegistry.detect('Help me solve this chess puzzle'), SpecialistMode.game);
    });
    test('detects business requests', () {
      expect(SpecialistRegistry.detect('Find prospects for my business'), SpecialistMode.business);
    });
    test('detects research requests', () {
      expect(SpecialistRegistry.detect('Research and compare these options'), SpecialistMode.research);
    });
    test('detects content requests', () {
      expect(SpecialistRegistry.detect('Write a marketing caption'), SpecialistMode.content);
    });
  });

  group('V5 command gateway', () {
    test('blocks communication and arbitrary shell actions', () {
      expect(CommandGateway.denialReason('send_sms'), isNotNull);
      expect(CommandGateway.denialReason('run_adb_command'), isNotNull);
      expect(CommandGateway.denialReason('run_safe_diagnostic'), isNotNull);
    });
    test('rejects unknown actions by default', () {
      expect(CommandGateway.denialReason('do_something_unlisted'), isNotNull);
    });
    test('allows basic navigation while unlocked', () {
      EmergencyStopController.instance.locked.value = false;
      expect(CommandGateway.denialReason('open_app'), isNull);
    });

    test('allows only the documented inner screen actions', () {
      expect(CommandGateway.taskActionDenial('click_text', 'Home screen'), isNull);
      expect(CommandGateway.taskActionDenial('run_safe_diagnostic', 'Home screen'), isNotNull);
      expect(CommandGateway.taskActionDenial('unknown_task_action', 'Home screen'), isNotNull);
      expect(CommandGateway.taskActionDenial('press_enter', 'Login form'), isNotNull);
      expect(CommandGateway.taskActionDenial('press_enter', 'Google search field'), isNull);
    });
    test('pauses on consequential or authentication screen text', () {
      expect(CommandGateway.taskActionDenial('click_text', 'Button: Send payment'), isNotNull);
      expect(CommandGateway.taskActionDenial('type_text', 'Enter your password'), isNotNull);
      expect(CommandGateway.taskActionDenial('done', 'Button: Confirm purchase'), isNull);
    });
    test('blocks all actions while emergency stop is locked', () {
      EmergencyStopController.instance.locked.value = true;
      expect(CommandGateway.denialReason('open_app'), isNotNull);
      EmergencyStopController.instance.locked.value = false;
    });
  });

  test('recognizes direct stop phrases', () {
    expect(EmergencyStopController.instance.isStopCommand('STOP!'), isTrue);
    expect(EmergencyStopController.instance.isStopCommand('cancel everything'), isTrue);
    expect(EmergencyStopController.instance.isStopCommand('please stop the music'), isFalse);
  });
}
