# PrivateAgent V5 — Changelog

## 2026-11-15 — V5 source milestone

- Started from the supplied `PrivateAgent_GIC_Hardened_V4_Source.zip`.
- Kept the supplied V4 archive unchanged.
- Used the supplied original archive as a reference only.
- Added Game, Business, Research and Content specialist modes.
- Added automatic keyword routing and manual specialist selection.
- Kept one shared `AiService` rather than starting separate AI processes.
- Added a deterministic emergency-stop controller with a persisted lock.
- Added exact chat stop phrases that remain sendable while a task is running, plus a confirmation-gated manual unlock command.
- Added a default-deny command gateway to the central action handler.
- Blocked communication actions, arbitrary shell/ADB, Shizuku diagnostics and unknown action names.
- Raised the bounded task action setting to 150 by default and 200 maximum.
- Removed the unbounded-steps setting.
- Disabled Telegram and Shizuku startup paths.
- Removed the Shizuku Android provider.
- Kept floating overlay disabled and removed its runtime entrypoint from `main.dart`.
- Updated Android app label and package version to V5.
- Added V5 policy tests and architecture/security documentation.

## Not yet complete

- Specialist-specific planners/tools and per-specialist memory.
- Full hybrid memory management UI.
- Network-change detection and safe task resumption.
- In-flight model request cancellation.
- Notification-level emergency stop action.
- Screenshot-sharing indicator and explicit capture policy controls.
- Device performance/thermal throttling.
- Full Flutter analyze/test/build and physical-device validation.
