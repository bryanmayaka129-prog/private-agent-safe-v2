# PrivateAgent V4 — Development Changelog

V4 is a development iteration of the existing PrivateAgent Android/Flutter project. It is not a replacement app and is not a verified release APK.

## Implemented in this source package

1. **OpenAI provider preset** — Settings now includes an OpenAI quick-select using `https://api.openai.com/v1` and the suggested model `gpt-6.1-terra`. The model remains editable; availability depends on the user's OpenAI API project. This preset uses the existing Chat Completions request path, not the OpenAI Responses API or its hosted computer-use tools.
2. **Safe diagnostic action is now connected** — the V3 prompt's `run_safe_diagnostic` action is now handled by `TaskExecutor`, validated against the two fixed identifiers `android_version` and `storage_summary`, and passed to the existing allowlisted Shizuku service. The service checks Shizuku availability before attempting execution. No AI-provided shell command is accepted.
3. **App label/version updated** — Android launcher label is `PrivateAgent V4`; Flutter version is `1.0.4+20261114`. The existing application ID is intentionally preserved so this remains the same project/app identity.
4. **API-key warning added to Settings** — explains that device-side secure storage is not a substitute for a server-side proxy in public/shared releases.
5. **Existing V1/V2/V3 security controls and task limits retained** — V4 starts from V3 rather than reintroducing removed direct calls/SMS/contacts/Telegram or arbitrary shell functionality.

## Not implemented yet (future V4 work)

- Dedicated game-solving/Game Mode.
- OpenAI Responses API integration, native function calling, hosted computer use, or web search tools.
- Business, Research, Content, and Earnings workflow modes.
- Hard technical approval gates for every consequential Android UI action. Current screen automation still uses generic Accessibility clicks and relies partly on task instructions; it is not a guaranteed submission/payment blocker.
- A server-side API-key proxy. The current app stores the user's key in Android secure storage and calls the provider directly from the device.

## Verification status

- ZIP integrity: to be verified when the source archive is packaged.
- Flutter formatting, dependency resolution, unit tests, Android compilation, and device testing: **not run in this environment** because Flutter/Dart tooling is unavailable.
- No APK is included.
