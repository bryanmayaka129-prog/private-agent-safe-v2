# V5 Security Review — Source Milestone

## Active protections

- Default-deny action gateway at `ActionHandler.execute`.
- Explicit allowlist for basic navigation, alarms/timers, volume/brightness, screen interaction and bounded task execution.
- Explicit denylist for calls, SMS, email sending, contact search, arbitrary ADB/shell, Shizuku diagnostics, financial actions, publishing, sharing, uploads, account deletion and security changes.
- Unknown actions denied.
- Emergency-stop latch persisted using SharedPreferences and restored during startup.
- Unbounded task-step setting removed; runtime clamp at 200.
- Floating overlay startup disabled; overlay permission removed from manifest.
- Telegram service is not initialized at startup.
- Shizuku provider removed from manifest and diagnostics denied.
- Existing HTTPS-only network policy and Android backup restriction retained from V4 manifest.

## Remaining risks / work

- Legacy source files and dependencies remain in the repository for build compatibility; keep them dormant and do not expose their methods through new UI or action paths.
- Review all code paths for direct handler invocation that could bypass `CommandGateway`.
- Secure-storage provider and API key handling require a fresh source audit and device verification.
- Chat history and skill memory need a complete data-retention and user-deletion review.
- Screen content may contain personal information. Add a persistent capture indicator, explicit capture policy, and clear external-provider disclosure before production.
- Implement HTTP cancellation so stop can cancel an in-flight model request, not only reject its eventual action.
- Add a foreground notification stop action and independent watchdog.
- Test Android exported components, intent filters, Accessibility service scope, and manifest merge output.
- Conduct dependency vulnerability and license review before distribution.

## Release gate

Do not distribute as a production or prop/business-critical agent until the remaining items are addressed, Flutter tests pass, a release APK is built, and target-device tests pass.
