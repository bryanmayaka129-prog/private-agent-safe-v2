# V5 Test Checklist

## Automated checks
- [ ] `flutter pub get`
- [ ] `flutter analyze`
- [ ] `flutter test`
- [ ] Release APK build

## Specialist routing
- [ ] Game prompt selects Game in automatic mode
- [ ] Prospecting prompt selects Business
- [ ] Comparison/research prompt selects Research
- [ ] Writing prompt selects Content
- [ ] Manual selection overrides automatic routing

## Emergency stop
- [ ] `STOP` locks the gateway
- [ ] `STOP IMMEDIATELY` locks the gateway
- [ ] `CANCEL EVERYTHING` locks the gateway
- [ ] Active task executor receives cancellation
- [ ] Further action proposals are denied
- [ ] Lock survives app process restart
- [ ] Unlock requires explicit phrase and confirmation
- [ ] Already-committed external actions are correctly described as irreversible

## Command gateway
- [ ] Basic navigation works
- [ ] Unknown actions are denied
- [ ] Calls/SMS/email/contact actions are denied
- [ ] Arbitrary shell/ADB and diagnostics are denied
- [ ] Financial, publishing, sharing and deletion actions are denied

## Android/device
- [ ] Overlay permission is absent
- [ ] No Telegram remote task listener starts
- [ ] No Shizuku provider is present in merged manifest
- [ ] Accessibility works only after deliberate user enablement
- [ ] Battery, thermal and memory behavior tested on Galaxy A03 Core / Android 13
- [ ] Network interruption and recovery tested
- [ ] Sensitive apps excluded from automation tests
