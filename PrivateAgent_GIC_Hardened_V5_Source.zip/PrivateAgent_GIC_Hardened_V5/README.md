# PrivateAgent V5 — G.I.C.

PrivateAgent V5 is a staged evolution of the supplied V4 Flutter/Android project. V4 was used as the source baseline; the supplied original archive was received but not merged into the V5 source. The V4 archive itself is not modified.

## V5 goals

- Preserve the familiar chat-first PrivateAgent interface.
- Add four specialist modes: Game, Business, Research and Content.
- Use one shared AI client; the specialist selector is lightweight and does not launch four separate models.
- Add a deterministic emergency-stop latch and a default-deny command gateway.
- Keep automation bounded (150 actions by default; absolute ceiling 200).
- Keep device control local to the phone by default: no Telegram remote-control startup and no floating overlay. The app can still send prompts and screen text to the AI provider configured by the user.
- Retain user-initiated accessibility-based screen workflows, subject to Android permissions and app compatibility.

## What is implemented in this source snapshot

| Area | V5 source status |
|---|---|
| V4 source preservation | Implemented: V4 archive was extracted to a separate build workspace; V4 ZIP is unchanged |
| Four specialist modes | Implemented: UI selector, automatic keyword routing and manual selection |
| Shared AI client | Implemented: all modes use the existing single `AiService` |
| Specialist-specific expert tools/planners | Scaffolded: mode context is passed to the shared model; dedicated specialist tools and evaluation loops are not complete |
| Emergency stop | Partially implemented: exact stop phrases can be sent even while a task is running; they engage a deterministic latch, request cancellation of the active task executor, persist the locked state, and block subsequent gateway actions |
| Stop during an in-flight HTTP/model request | Not guaranteed: the current HTTP stream is not yet wired to a cancellation token; the gateway still blocks any action returned after the stop |
| Default-deny command gateway | Implemented for `ActionHandler` and the inner multi-step screen-action loop: explicit allowlists; communication, arbitrary shell, diagnostics and unknown actions are blocked |
| Manual unlock | Implemented through the exact `UNLOCK AUTOMATION` chat command and a confirmation dialog |
| Bounded action budget | Implemented: 150 default, configurable to 200; unbounded mode removed from Settings and runtime clamp is 200 |
| Periodic checkpoints | Partially implemented: progress checkpoint message every 15 loop steps; risky screen-text heuristic pauses multi-step automation; richer state validation and budget accounting remain |
| No floating overlay | Disabled in V5 startup; manifest strips overlay permission; old dormant overlay source/dependency remains for compatibility and is not a V5 feature |
| No Telegram remote control | Telegram service is not initialized at startup; remote access is not part of the V5 workflow |
| Shizuku / arbitrary shell | Shizuku provider removed from manifest; safe diagnostic and arbitrary shell actions are blocked by the gateway; legacy source/dependency remains dormant |
| Hybrid memory | Not complete: chat history remains; automatic replay of legacy saved action sequences is disabled pending gateway integration; V5 user-approved long-term memory controls and specialist memory partitions are not yet built |
| Network recovery | Not complete: existing task recovery remains; network-change detection and safe resume checkpoints are future work |
| Notification stop action | Not implemented yet |
| Screenshot consent/indicator policy | Not fully implemented: screen reading remains user-initiated, but there is not yet a dedicated per-capture confirmation or persistent capture indicator |
| Performance adaptation | Not complete: device-specific battery/thermal/memory throttling still requires implementation and physical-device testing |

## Safety boundaries

- No arbitrary shell/ADB command execution.
- No direct calls, SMS, email sending or contact search through the action gateway.
- No payments, transfers, purchases, publishing, sharing, uploads, account deletion or security-setting changes through the action gateway.
- Unknown action names are denied.
- Emergency Stop locks new actions until the user confirms a manual unlock.
- Android Accessibility is powerful. Enable it only when the user deliberately starts screen automation and understands that visible screen content may be read by the app and, depending on the configured AI provider/workflow, sent to that provider.
- The emergency stop cannot undo actions already accepted by another app or remote service.

## Build

Requirements:
- Flutter SDK compatible with the Dart constraint in `pubspec.yaml`.
- Git for Windows available on PATH (the Flutter SDK launcher used in the user's previous setup required Git).
- Android SDK and Java configured.

From the project root:

```bat
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

The commands above are instructions, not evidence that this source snapshot has already been built. No APK is included and no Android device test is claimed.

## Recommended validation order

1. Run `flutter pub get`.
2. Run `flutter analyze` and resolve all compile/analyzer errors.
3. Run `flutter test`.
4. Build a debug APK and install it on a spare/test device.
5. Verify chat-only use with no API key configured.
6. Verify each specialist mode selection and automatic detection.
7. Verify `STOP`, `STOP IMMEDIATELY`, `CANCEL EVERYTHING` and `DISABLE AUTOMATION`.
8. Verify automation remains locked after force-stop/relaunch and only unlocks after the confirmation dialog.
9. Verify blocked action names cannot reach a handler.
10. Verify accessibility workflows only on non-sensitive test apps.
11. Test battery, memory, heat, network loss and app lifecycle on the target Android device.
12. Do not use banking, wallet, trading, authentication or other sensitive apps for automation testing.

## Important

This is a V5 source implementation milestone, not a verified production release. Specialist-specific reasoning and tools, complete hybrid memory, network recovery, screenshot indicators, notification stop action, and full device testing remain outstanding. Do not treat the app as production-safe until the release checklist is completed.
