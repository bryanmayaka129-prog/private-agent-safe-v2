class FeatureFlags {
  FeatureFlags._();

  // V5 release defaults: no floating overlay and no remote-control startup.
  static const bool floatingOverlayEnabled = false;
  static const bool autonomousScreenActionsEnabled = true;
  static const bool remoteTelegramEnabled = false;
  static const bool shizukuEnabled = false;
  static const bool v5CommandGatewayEnabled = true;
}
