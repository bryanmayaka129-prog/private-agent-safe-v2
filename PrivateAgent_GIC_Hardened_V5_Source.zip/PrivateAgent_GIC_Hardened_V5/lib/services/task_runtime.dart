import 'dart:async';
import 'package:flutter/foundation.dart';
import 'emergency_stop_controller.dart';
import 'specialist_registry.dart';

/// Runtime state and guardrails shared by specialist workflows.
class TaskRuntime {
  TaskRuntime._();
  static final TaskRuntime instance = TaskRuntime._();

  final ValueNotifier<bool> running = ValueNotifier<bool>(false);
  final ValueNotifier<int> completedActions = ValueNotifier<int>(0);
  final ValueNotifier<String> currentMode = ValueNotifier<String>('Research');
  final ValueNotifier<String> currentTask = ValueNotifier<String>('');
  DateTime? _startedAt;
  int _ineffectiveActions = 0;

  void begin({required SpecialistMode mode, required String goal}) {
    if (EmergencyStopController.instance.locked.value) {
      throw StateError('Emergency Stop is engaged.');
    }
    running.value = true;
    completedActions.value = 0;
    currentMode.value = mode.label;
    currentTask.value = goal;
    _startedAt = DateTime.now();
    _ineffectiveActions = 0;
  }

  bool recordAction({required bool madeProgress}) {
    if (EmergencyStopController.instance.locked.value) return false;
    completedActions.value++;
    _ineffectiveActions = madeProgress ? 0 : _ineffectiveActions + 1;
    if (completedActions.value >= SpecialistRegistry.defaultActionBudget ||
        _ineffectiveActions >= 3 ||
        DateTime.now().difference(_startedAt ?? DateTime.now()) >
            const Duration(minutes: 20)) {
      pause('Safety checkpoint reached');
      return false;
    }
    return true;
  }

  void pause([String reason = 'Paused']) {
    running.value = false;
    currentTask.value = reason;
  }

  void finish() {
    running.value = false;
    currentTask.value = '';
  }
}
