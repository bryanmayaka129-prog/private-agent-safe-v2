import 'package:shizuku_api/shizuku_api.dart';

class ShizukuService {
  final ShizukuApi _shizuku = ShizukuApi();
  bool _isAvailable = false;
  bool _hasPermission = false;

  bool get isAvailable => _isAvailable;
  bool get hasPermission => _hasPermission;

  /// Check if Shizuku is installed and running
  Future<bool> checkAvailability() async {
    try {
      _isAvailable = await _shizuku.pingBinder() ?? false;
      if (_isAvailable) {
        _hasPermission = await _shizuku.checkPermission() ?? false;
      }
      return _isAvailable;
    } catch (e) {
      _isAvailable = false;
      _hasPermission = false;
      return false;
    }
  }

  /// Request Shizuku permission
  Future<bool> requestPermission() async {
    if (!_isAvailable) return false;
    try {
      _hasPermission = await _shizuku.requestPermission() ?? false;
      return _hasPermission;
    } catch (e) {
      return false;
    }
  }

  /// Run one of the fixed, read-only diagnostics exposed by V3.
  /// The model cannot provide shell text or arguments.
  Future<String> runSafeDiagnostic(String diagnostic) async {
    const commands = <String, String>{
      'android_version': 'getprop ro.build.version.release',
      'storage_summary': 'df -h /data',
    };
    final command = commands[diagnostic];
    if (command == null) {
      return 'Unsupported diagnostic. Only android_version and storage_summary are allowed.';
    }
    await checkAvailability();
    return _runCommand(command);
  }

  /// Low-level shell runner retained internally for fixed, reviewed commands.
  /// Do not expose this method to AI-provided command strings.
  Future<String> _runCommand(String command) async {
    if (!_isAvailable) {
      return 'Shizuku is not running. Please start Shizuku first.';
    }
    if (!_hasPermission) {
      final granted = await requestPermission();
      if (!granted) {
        return 'Shizuku permission denied.';
      }
    }

    try {
      final result = await _shizuku.runCommand(command);
      return result ?? 'Command executed (no output)';
    } catch (e) {
      return 'Error running command: $e';
    }
  }

}
