enum SpecialistMode { game, business, research, content }

extension SpecialistModeLabel on SpecialistMode {
  String get label => switch (this) {
    SpecialistMode.game => 'Game',
    SpecialistMode.business => 'Business',
    SpecialistMode.research => 'Research',
    SpecialistMode.content => 'Content',
  };
  String get description => switch (this) {
    SpecialistMode.game => 'Understand game state and plan adaptive moves.',
    SpecialistMode.business => 'Research prospects and prepare business workflows.',
    SpecialistMode.research => 'Investigate, verify sources and structure findings.',
    SpecialistMode.content => 'Draft, edit and plan content for review.',
  };
}

/// Lightweight mode selection/detection. The shared AI service remains the
/// single model client; specialist-specific execution is loaded on demand.
class SpecialistRegistry {
  static SpecialistMode detect(String text) {
    final q = text.toLowerCase();
    if (RegExp(r'\b(game|gaming|level|boss fight|puzzle|chess|minecraft|roblox)\b').hasMatch(q)) {
      return SpecialistMode.game;
    }
    if (RegExp(r'\b(prospect|client|customer|business|sales|lead|outreach|company)\b').hasMatch(q)) {
      return SpecialistMode.business;
    }
    if (RegExp(r'\b(research|compare|investigate|sources|evidence|analyse|analyze)\b').hasMatch(q)) {
      return SpecialistMode.research;
    }
    if (RegExp(r'\b(write|draft|edit|script|caption|content|marketing|post)\b').hasMatch(q)) {
      return SpecialistMode.content;
    }
    return SpecialistMode.research;
  }

  static const int defaultActionBudget = 150;
  static const int maximumActionBudget = 200;
  static const int checkpointInterval = 15;
}
