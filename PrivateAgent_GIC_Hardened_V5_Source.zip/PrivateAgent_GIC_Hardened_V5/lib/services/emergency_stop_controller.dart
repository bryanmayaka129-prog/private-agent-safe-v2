import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Deterministic stop latch. This controller does not depend on an LLM response.
class EmergencyStopController {
  EmergencyStopController._();
  static final EmergencyStopController instance = EmergencyStopController._();

  final ValueNotifier<bool> locked = ValueNotifier<bool>(false);
  final ValueNotifier<String> status = ValueNotifier<String>('Ready');
  final Set<void Function()> _cancellers = <void Function()>{};

  static const String _lockKey = 'v5_emergency_stop_locked';

  Future<void> restore() async {
    final prefs = await SharedPreferences.getInstance();
    final wasLocked = prefs.getBool(_lockKey) ?? false;
    locked.value = wasLocked;
    status.value = wasLocked ? 'Locked — automation stopped' : 'Ready';
  }

  static const Set<String> _stopPhrases = {
    'stop', 'stop now', 'stop everything', 'stop immediately', 'cancel task', 'cancel everything', 'disable automation', 'pause automation',
    'emergency stop', 'halt', 'abort task',
  };

  bool isStopCommand(String input) {
    final normalized = input.trim().toLowerCase().replaceAll(RegExp(r'[.!?]+$'), '');
    return _stopPhrases.contains(normalized);
  }

  void registerCanceller(void Function() cancel) => _cancellers.add(cancel);
  void unregisterCanceller(void Function() cancel) => _cancellers.remove(cancel);

  Future<void> triggerStop() async {
    // Set the in-memory latch before awaiting storage or UI work.
    locked.value = true;
    status.value = 'Locked — automation stopped';
    for (final cancel in List<void Function()>.from(_cancellers)) {
      try { cancel(); } catch (_) { /* Continue stopping other workers. */ }
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_lockKey, true);
  }

  Future<bool> unlockManually({required bool confirmed}) async {
    if (!confirmed) return false;
    locked.value = false;
    status.value = 'Ready';
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_lockKey, false);
    return true;
  }
}
