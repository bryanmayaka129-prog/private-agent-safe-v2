import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class TaskHistoryLogger {
  // Redact credential-like values from locally persisted task descriptions/traces.
  // This is a best-effort privacy filter, not a guarantee against all secrets.
  static String _redactSensitive(String input) {
    var value = input;
    value = value.replaceAll(
      RegExp(r'(?i)(password|passcode|pin|otp|one[- ]time code|verification code|api[_ -]?key|access[_ -]?token|refresh[_ -]?token|recovery code)(\s*[:=]\s*)([^\s,;]+)'),
      r'$1$2[REDACTED]',
    );
    value = value.replaceAll(
      RegExp(r'(?i)bearer\s+[A-Za-z0-9._~+/-]+=*'),
      'Bearer [REDACTED]',
    );
    value = value.replaceAll(
      RegExp(r'(?i)\b(sk-[A-Za-z0-9_-]{12,})\b'),
      '[REDACTED_API_KEY]',
    );
    return value;
  }

  static Future<File> get _localFile async {
    final directory = await getApplicationDocumentsDirectory();
    return File('${directory.path}/task_history.jsonl');
  }

  /// Appends a task execution record to the history file
  static Future<void> logTask(String goal, String status, int totalTokens, int steps, List<String> trace) async {
    try {
      final file = await _localFile;
      
      final data = {
        "goal": _redactSensitive(goal.trim()),
        "status": status, // "Success", "Failed", "Cancelled"
        "total_tokens": totalTokens,
        "steps_taken": steps,
        "trace": trace.map(_redactSensitive).toList(),
        "timestamp": DateTime.now().toIso8601String(),
      };
      
      await file.writeAsString('${jsonEncode(data)}\n', mode: FileMode.append);
    } catch (e) {
      print('Failed to write task history: $e');
    }
  }

  /// Reads the entire task history file for previewing
  static Future<List<Map<String, dynamic>>> readHistory() async {
    try {
      final file = await _localFile;
      if (!await file.exists()) return [];

      final lines = await file.readAsLines();
      return lines
          .where((line) => line.trim().isNotEmpty)
          .map((line) => jsonDecode(line) as Map<String, dynamic>)
          .toList()
          .reversed
          .toList(); // newest first
    } catch (e) {
      print('Failed to read task history: $e');
      return [];
    }
  }

  /// Clears the task history file
  static Future<void> clearHistory() async {
    try {
      final file = await _localFile;
      if (await file.exists()) {
        await file.delete();
      }
    } catch (e) {
      print('Failed to clear task history: $e');
    }
  }

  /// Calculates analytics from task history
  static Future<Map<String, dynamic>> getAnalytics() async {
    final history = await readHistory();
    if (history.isEmpty) {
      return {
        'totalTasks': 0,
        'successRate': 0.0,
        'successCount': 0,
        'failedCount': 0,
      };
    }

    int successCount = 0;
    int failedCount = 0;

    for (final task in history) {
      if (task['status'] == 'Success') {
        successCount++;
      } else if (task['status'] == 'Failed' || task['status'] == 'Cancelled') {
        failedCount++;
      }
    }

    return {
      'totalTasks': history.length,
      'successRate': successCount / history.length,
      'successCount': successCount,
      'failedCount': failedCount,
    };
  }
}
