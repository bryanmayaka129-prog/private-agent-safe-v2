import 'emergency_stop_controller.dart';

/// Default-deny action gateway. This is a policy boundary, not an AI prompt.
class CommandGateway {
  static const Set<String> _allowedActions = {
    'general_query', 'open_app', 'launch_package', 'open_url',
    'set_alarm', 'set_timer', 'set_volume', 'set_brightness',
    'read_screen', 'click_element', 'type_on_screen',
    'press_back', 'scroll_screen', 'execute_task',
  };

  static const Set<String> _alwaysBlocked = {
    'make_call', 'send_sms', 'send_email', 'search_contact',
    'run_adb_command', 'run_safe_diagnostic', 'transfer_money',
    'make_payment', 'purchase', 'delete_account', 'publish_post',
    'share_file', 'upload_file', 'change_security_settings',
  };

  static String? denialReason(String action) {
    if (EmergencyStopController.instance.locked.value) {
      return 'Automation is locked by Emergency Stop. Manually unlock it in Settings before starting another task.';
    }
    if (_alwaysBlocked.contains(action)) {
      return 'Blocked by the V5 command gateway: this action is not permitted.';
    }
    if (!_allowedActions.contains(action)) {
      return 'Blocked by the V5 command gateway: unknown or unapproved action.';
    }
    return null;
  }

  static const Set<String> _allowedTaskActions = {
    'click_text', 'click_at', 'type_text', 'press_enter', 'scroll',
    'swipe', 'press_back', 'press_home', 'open_app', 'wait', 'done',
  };

  static String? taskActionDenial(String action, String screenContent) {
    if (EmergencyStopController.instance.locked.value) {
      return 'Emergency Stop is engaged.';
    }
    if (!_allowedTaskActions.contains(action)) {
      return 'Task action denied: unknown or unapproved screen action.';
    }
    final riskyScreen = RegExp(
      r'\b(send|buy|purchase|pay|transfer|book|confirm|delete|publish|post|share|upload|submit|password|passcode|one[- ]time code|verification code|sign in|log in|bank|wallet|trading|broker|authenticator|whatsapp|telegram|messenger|messages|sms|gmail|outlook|mail)\b',
      caseSensitive: false,
    );
    if (action != 'done' && riskyScreen.hasMatch(screenContent)) {
      return 'Automation paused because the current screen may contain a consequential action or authentication step. Please take over manually.';
    }
    if (action == 'press_enter' &&
        !RegExp(r'\b(search|google|chrome|query|address bar)\b', caseSensitive: false)
            .hasMatch(screenContent)) {
      return 'Enter is restricted to visible search/address fields. Automation paused so a form cannot be submitted accidentally.';
    }
    return null;
  }
}
