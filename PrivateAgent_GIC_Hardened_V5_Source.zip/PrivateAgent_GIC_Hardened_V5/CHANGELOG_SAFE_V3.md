# PrivateAgent Safe V3 — development source

## Changes from V2
- Increased the task executor hard cap from 20 to 100 actions.
- Increased saved-skill replay validation to 100 actions.
- Increased the Settings slider maximum to 100; new default is 100 actions. Existing saved values are clamped to 5–100.
- Added two fixed, read-only Shizuku diagnostics: Android version and `/data` storage summary. The AI cannot provide arbitrary shell text or arguments. Arbitrary `run_adb_command` remains blocked. Shizuku must be installed/running and its permission granted by the user.
- Added best-effort redaction of password/PIN/OTP/API-key/token-like values in task goals and traces before local task-history persistence. This is not a complete secret detector.
- Clarified that ordinary user-provided profile details/documents may be used when deliberately supplied for a task; passwords, PINs, OTPs, API keys and recovery codes remain prohibited.

## Intentionally unchanged / not yet implemented
- No unrestricted shell, file mutation, package installation, app uninstall, security bypass, or arbitrary script execution.
- No general-purpose file picker/document ingestion was added in this source pass. Existing screen-reading capability remains; user-selected document access still needs a dedicated implementation.
- No technical approval gate for final form submission, payments, or destructive actions has been added. The task prompt continues to stop before consequential submissions/actions.
- Existing Accessibility capability remains powerful and should not be used in banking, payment, wallet, trading, or authentication apps.

## Validation status
This is a source ZIP only. It has not been compiled, tested on a device, or security-audited as a release. Review and run Flutter tests/build before installing. V2 source archive was not modified.
